function uploadFile() {
  var fileInput = document.getElementById('fileInput');
  var file = fileInput.files[0];
  if (file) {
    var fileName = file.name; // 取得檔案名稱
    console.log('上傳檔案名稱：', fileName);

    var reader = new FileReader();

    reader.onload = function(event) {
      var fileContent = event.target.result; // 取得檔案內容
      var dialogContainer = document.getElementById('dialogContainer');
      // 將換行符號轉換為 <br> 標籤
      var formattedContent = fileContent.replace(/\n/g, '<br>');
      dialogContainer.innerHTML = formattedContent;
    };

    reader.readAsText(file); // 讀取檔案內容

    alert('檔案上傳成功！');
  } else {
    alert('請選擇要上傳的檔案！');
  }
}
function checkFile() {
  var statusContainer = document.getElementById('statusContainer');
  //var loadingImage = document.createElement('img');
  //loadingImage.src = '';
  //loadingImage.alt = 'Loading...';

  var statusText = document.createElement('p');
  statusText.textContent = '檢核中，請稍後...';

  statusContainer.innerHTML = '';
  //statusContainer.appendChild(loadingImage);
  statusContainer.appendChild(statusText);

  setTimeout(function() {
    statusContainer.innerHTML = '檢核完成！';
    var Container = document.getElementById('dialogContainer');
    dialogContainer.style.display = 'block';
    aScore.style.display = 'block';
    vScore.style.display = 'block';
    wScore.style.display = 'block';

  }, 3000);

}